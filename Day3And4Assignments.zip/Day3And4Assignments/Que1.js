function changeImg(){
    const ele=document.getElementById("image");
    const newUrl="https://wallpaperhook.com/wp-content/uploads/2019/06/daenerys-targaryen-3606x2400-emilia-clarke-game-of-thrones-season-7.jpg";
    ele.src=newUrl;
}
function changeImg1(){
    const ele=document.getElementById("image");
    const newUrl="https://images.spot.im/v1/production/fml3vk03iunpwvjnuxsx";
    ele.src=newUrl;
}
function changeImg2(){
    const ele=document.getElementById("image");
    const newUrl="https://movieposterhd.com/wp-content/uploads/2019/03/Game-of-Thrones-Jon-Snow-Wallpaper-HD.jpg";
    ele.src=newUrl;
}