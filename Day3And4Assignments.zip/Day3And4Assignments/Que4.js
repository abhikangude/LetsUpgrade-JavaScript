let info=[
    {
        name:"Eleven",
        age:13,
        country:"Hawkins",
        Hobbies:["Eating eggos","Watching TV"],
    },
    {
        name:"Jonas Kanhwald",
        age:19,
        country:"Winden",
        Hobbies:["Wear yellow raincoat for no reason","Finding your own reality","Time traveling"],
    },
    {
        name:"Jim Hopper",
        age:42,
        country:"Hawkins",
        Hobbies:["Investigation","Music","Risking life"],
    },
    {
        name:"Hathiram Chaudhary",
        age:45,
        country:"India",
        Hobbies:["Police Duty","Music","Risking life"],
    },
];
function dispAge(info){
    console.log("******************************************************************");
    console.log("People with age less than 30-->")
    info.forEach(element=>{
        if(element.age<30){
            console.log("Name: "+element.name);
            console.log("Age: "+element.age);
            console.log("Country: "+element.country);
            console.log("Hobbies: "+element.Hobbies);
            console.log("----------------------------------------------------");
        }
    }); 
}

function dispCountry(info){
    console.log("******************************************************************");
    console.log("People having country India-->")
    info.forEach(element=>{
        if(element.country=="India"){
            console.log("Name: "+element.name);
            console.log("Age: "+element.age);
            console.log("Country: "+element.country);
            console.log("Hobbies: "+element.Hobbies);
            console.log("----------------------------------------------------");
        }
    }); 
}
dispAge(info);
dispCountry(info);