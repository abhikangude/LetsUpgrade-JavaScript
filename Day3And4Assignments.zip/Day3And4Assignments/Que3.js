let info=[
    {
        name:"Eleven",
        age:13,
        country:"Hawkins",
        Hobbies:["Eating eggos","Watching TV"],
    },
    {
        name:"Jonas Kanhwald",
        age:19,
        country:"Winden",
        Hobbies:["Wear yellow raincoat for no reason","Finding your own reality","Time traveling"],
    },
    {
        name:"Jim Hopper",
        age:42,
        country:"Hawkins",
        Hobbies:["Investigation","Music","Risking life"],
    },
    {
        name:"Hathiram Chaudhary",
        age:45,
        country:"India",
        Hobbies:["Police Duty","Music","Risking life"],
    },
];
function disp(){
    for(let i=0;i<info.length;i++){
        console.log("Name: "+info[i].name);
        console.log("Age: "+info[i].age);
        console.log("Country: "+info[i].country);
        console.log("Hobbies: "+info[i].Hobbies);
        console.log("----------------------------------------------------");
    }
}
disp();