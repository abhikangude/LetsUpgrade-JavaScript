function change(){
    var ele1=document.getElementById("n1");
    var ele2=document.getElementById("n2");
    ele2.value=ele1.value;
}