let countval=0;
let products = [
    {
        id: 1,
        name: "White Shirt",
        size: "L",
        color: "White",
        price: 1500,
        image: "../whiteshirt.jpg",
        description: "White shirt with stylish design",
    },
    {
      id: 2,
      name: "Red-Black Shirt",
      size: "M",
      color: "Red-Black",
      price: 1800,
      image: "../redblackcasualshirt.jpg",
      description: "Red Black Shirt with checkboard design",
    },
  
    {
      id: 3,
      name: "Denim Shirt",
      size: "L",
      color: "Denim",
      price: 2500,
      image: "../denimshirt.jpg",
      description: "Denim shirt with mandarin collar",
    },
  
    {
      id: 4,
      name: "Yellow-Black Checked ",
      size: "M,L",
      color: "Yellow-Black",
      price: 2000,
      image: "../Checkedyellowshirt.jpg",
      description: "Classy yellow and black shirt with checks",
    },
  
    {
      id: 5,
      name: "Sporty Jacket",
      size: "S,M,L",
      color: "Green",
      price: 1800,
      image: "../sportyjacket.jpg",
      description: "Slim fit Sports jacket",
    },
  
    {
      id: 6,
      name: "Denim Jacket",
      size: "M,L",
      color: "Denim",
      price: 2800,
      image: "../denimjacket.jpg",
      description: "Denim Jacket with hoodie",
    },
    {
        id: 7,
        name: "Pink Shirt",
        size: "S,M,L",
        color: "Pink",
        price: 1200,
        image: "../strippedshirt.jpg",
        description: "Pink shirt with blue striped and regular sleeves",
      },
      {
        id: 8,
        name: "Green Top",
        size: "S,M,L",
        color: "Solid Green",
        price: 1500,
        image: "../ALineKurti.jpg",
        description: "Green kurti with beautiful printing",
      },
      {
        id: 9,
        name: "Black Maxi Dress",
        size: "M,L",
        color: "Black",
        price: 2300,
        image: "../blackdress.jpg",
        description: "Black coloured maxi dress with beautiful printing",
      },
      {
        id: 10,
        name: "Red Sneakers",
        size: "7,8,9,10(UK)",
        color: "Red-Black",
        price: 3000,
        image: "../redsneakers.jpg",
        description: "Red-Black Solid sneakers for men",
      },
      {
        id: 11,
        name: "Brown Loafers",
        size: "7,8,9,10(UK)",
        color: "Brown",
        price: 2500,
        image: "../brownsneakers.jpg",
        description: "Brown coloured Loafers for men",
      },
      {
        id: 12,
        name: "White Sneakers",
        size: "7,8,9,10(UK)",
        color: "White",
        price: 2800,
        image: "../whitesneakers.jpg",
        description: "Unisex White Sneakers",
      },
  ];
  
  cart = [];
  
  function displayProducts(productsData, who = "productwrapper") {
    let productsString = "";
  
    productsData.forEach(function (product, index) {
      let { id, name, image, color, description, price, size } = product;
  
      if (who == "productwrapper") {
        productsString += ` <div class="product">
          <div class="prodimg">
            <img src="productimages/${image}" width="100%" />
          </div>
          <h3>${name}</h3>
          <p>Price : ${price}$</p>
          <p>Size : ${size}</p>
          <p>Color : ${color}</p>
          <p>${description}</p>
          <p>
            <button onclick="addToCart(${id})">Add to Cart</button>
          </p>
        </div>`;
      } else if (who == "cart") {
        productsString += ` <div class="product">
          <div class="prodimg">
            <img src="productimages/${image}" width="100%" />
          </div>
          <h3>${name}</h3>
          <p>Price : ${price}$</p>
          <p>Size : ${size}</p>
          <p>Color : ${color}</p>
          <p>${description}</p>
          <p>
            <button onclick="removeFromCart(${id})">Remove from Cart</button>
          </p>
        </div>`;
      }
    });
  
    document.getElementById(who).innerHTML = productsString;
  }
  
  displayProducts(products);
  
  function searchProduct(searchValue) {
    let searchedProducts = products.filter(function (product, index) {
      let searchString =
        product.name + " " + product.color + " " + product.description;
  
      return searchString.toUpperCase().indexOf(searchValue.toUpperCase()) != -1;
    });
  
    displayProducts(searchedProducts);
  }
  
  function getProductByID(productArray, id) {
    return productArray.find(function (product) {
      return product.id == id;
    });
  }

  function updateCount(){
    document.getElementById("count").innerHTML = countval;
  }

  let flag=false;
  function addToCart(id) {
    flag=false;
    let pro = getProductByID(products, id);
    cart.forEach(function(element){
      if(element.id==pro.id){
        flag=true;
      }
    })
    if(flag){
      alert("You've already added this product!!!");
      return 0;
    }
    cart.push(pro);
     countval++;
     updateCount();
     displayProducts(cart,"cart");
   }

  function removeFromCart(id) {
    let index = cart.findIndex(function (product) {
      return product.id == id;
    });
  
    cart.splice(index, 1);
    displayProducts(cart, "cart");
    countval--;
    updateCount();
  }
  
  function filter(){
    let minv=document.getElementById("minp").value;
    let maxv = document.getElementById("maxp").value;
    let items= products.filter(function(itemsl){
        return itemsl.price>=minv && itemsl.price<=maxv;
    })
    displayProducts(items);
    document.getElementById("minp").value="";
    document.getElementById("maxp").value="";
}