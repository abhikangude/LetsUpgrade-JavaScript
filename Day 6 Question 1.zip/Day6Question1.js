let Employee = [
    {
      name: "Chandler",
      age: 35,
      city: "Manhattan",
      salary: 15000,
    },
    {
      name: "Ross",
      age: 38,
      city: "London",
      salary: 18000,
    },
    {
        name: "Joey",
        age: 33,
        city: "Manhattan",
        salary: 14000,
    },
  ];
  function display(superarray) {
    let tabledata = "";
    let srno = 1;
    superarray.forEach(function (emp,index) {
      let currentrow = `<tr>
      <td>${srno}</td>
      <td>${emp.name}</td>
      <td>${emp.age}</td>
      <td>${emp.city}</td>
      <td>${emp.salary}</td>
      <td><button onclick='deleteEmployee(${index})'>Delete</button>
      </td>
      </tr>`;
      tabledata += currentrow;
      srno++;
    });
     document.getElementsByClassName("tdata")[0].innerHTML = tabledata;
  }
  display(Employee);
  function addEmployee(event) {
    event.preventDefault();
    let emp = {};
    let name = document.getElementById("name").value;
    let age = document.getElementById("age").value;
    let city = document.getElementById("city").value;
    let salary = document.getElementById("salary").value;
    emp.name = name;
    emp.age = age;
    emp.city = city;
    emp.salary = salary;
    Employee.push(emp);
    console.log(emp);
    display(Employee);
    document.getElementById("name").value = "";
    document.getElementById("age").value = "";
    document.getElementById("city").value = "";
    document.getElementById("salary").value = "";

  }
  function searchByCity() {
    let searchValue = document.getElementById("searchName").value;
    let newdata=Employee.filter(function (emp) {
        return (emp.name.toUpperCase().indexOf(searchValue.toUpperCase()) != -1)||(emp.city.toUpperCase().indexOf(searchValue.toUpperCase()) != -1);
    });
    display(newdata);
  }
  function deleteEmployee(index)
  {
    Employee.splice(index,1);
    display(Employee);
  }